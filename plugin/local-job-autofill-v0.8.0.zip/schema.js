const PROFILE_VERSION = 3;

const COMMON_OPTIONS = {
  gender: ["男", "女", "其他", "不便透露"],
  idType: ["身份证", "护照", "港澳居民来往内地通行证", "台湾居民来往大陆通行证", "其他"],
  ethnicity: ["汉族", "蒙古族", "回族", "藏族", "维吾尔族", "苗族", "彝族", "壮族", "布依族", "朝鲜族", "满族", "其他"],
  country: ["中国", "中国香港", "中国澳门", "中国台湾", "美国", "英国", "加拿大", "澳大利亚", "新加坡", "日本", "韩国", "其他"],
  politicalStatus: ["中共党员", "中共预备党员", "共青团员", "群众", "民主党派", "其他"],
  maritalStatus: ["未婚", "已婚", "离异", "其他"],
  healthStatus: ["良好", "健康", "一般"],
  degree: ["高中", "大专", "本科", "硕士", "博士", "其他"],
  yesNo: ["是", "否"],
  rank: ["前5%", "前10%", "前20%", "前30%", "前50%", "其他", "不详"],
  educationType: ["国内学历", "海外学历", "交换项目", "联合培养", "其他"],
  studyMode: ["全日制", "非全日制", "其他"],
  source: ["学校就业网站", "学校宣讲会", "企业官网", "招聘公众号", "招聘平台", "员工推荐", "导师/同学推荐", "其他"],
  jobType: ["全职", "实习", "兼职"],
  experienceType: ["实习", "全职工作", "兼职", "志愿服务", "其他"],
  awardType: ["奖学金", "荣誉称号", "竞赛奖项", "优秀学生/干部", "其他"],
  awardResult: ["特等奖", "一等奖", "二等奖", "三等奖", "金奖", "银奖", "铜奖", "优秀奖", "入围", "其他"],
  competitionType: ["专业竞赛", "学术竞赛", "创新创业", "语言/翻译", "案例分析", "文体竞赛", "其他"],
  publicationType: ["期刊论文", "会议论文", "学位论文", "研究报告", "案例分析", "其他"],
  authorOrder: ["第一作者", "共同第一作者", "第二作者", "第三作者", "通讯作者", "独立作者", "其他"]
};

const FIELD_DEFINITIONS = [
  { key: "name", label: "姓名", required: true, aliases: ["姓名", "中文名", "name"] },
  { key: "namePinyin", label: "姓名拼音", aliases: ["姓名拼音", "拼音", "英文姓名", "english name"] },
  { key: "mobile", label: "手机号码", required: true, aliases: ["手机", "手机号", "手机号码", "联系电话", "电话", "mobile", "phone"] },
  { key: "email", label: "邮箱", required: true, aliases: ["邮箱", "电子邮箱", "电子邮件", "email", "e-mail"] },
  { key: "gender", label: "性别", options: COMMON_OPTIONS.gender, aliases: ["性别", "gender"] },
  { key: "birthDate", label: "出生日期", aliases: ["出生日期", "出生年月", "生日", "birth date", "birthday"] },
  { key: "idType", label: "证件类型", options: COMMON_OPTIONS.idType, aliases: ["证件类型", "证件类别", "id type"] },
  { key: "idNumber", label: "身份证号码", sensitive: true, aliases: ["身份证", "身份证号", "证件号码", "证件号", "id number"] },
  { key: "nativePlace", label: "籍贯", aliases: ["籍贯", "native place"] },
  { key: "ethnicity", label: "民族", options: COMMON_OPTIONS.ethnicity, aliases: ["民族", "ethnicity"] },
  { key: "nationality", label: "国籍", options: COMMON_OPTIONS.country, aliases: ["国籍", "nationality"] },
  { key: "birthCountry", label: "出生国家", options: COMMON_OPTIONS.country, aliases: ["出生国家", "出生地国家", "country of birth"] },
  { key: "currentCountry", label: "当前所在国家", options: COMMON_OPTIONS.country, aliases: ["当前所在国家", "现居国家", "current country"] },
  { key: "politicalStatus", label: "政治面貌", options: COMMON_OPTIONS.politicalStatus, aliases: ["政治面貌", "political status"] },
  { key: "maritalStatus", label: "婚姻状况", options: COMMON_OPTIONS.maritalStatus, aliases: ["婚姻状况", "婚姻状态"] },
  { key: "healthStatus", label: "健康状况", options: COMMON_OPTIONS.healthStatus, aliases: ["健康状况", "身体状况"] },
  { key: "hukou", label: "户籍所在地", aliases: ["户籍", "户口所在地", "户籍所在地"] },
  { key: "currentCity", label: "当前所在城市", aliases: ["当前所在城市", "现居城市", "目前所在城市"] },
  { key: "address", label: "联系地址", sensitive: true, aliases: ["联系地址", "通讯地址", "现居地址", "家庭地址"] },
  { key: "wechat", label: "微信号", sensitive: true, aliases: ["微信号", "微信", "wechat"] },
  { key: "emergencyContact", label: "紧急联系人", sensitive: true, aliases: ["紧急联系人", "应急联系人"] },
  { key: "emergencyPhone", label: "紧急联系人电话", sensitive: true, aliases: ["紧急联系人电话", "应急联系电话"] },
  { key: "graduationYear", label: "毕业年份", aliases: ["毕业年份", "毕业年度", "graduation year"] },
  { key: "highestDegree", label: "最高学历", options: COMMON_OPTIONS.degree, aliases: ["最高学历", "学历", "degree"] },
  { key: "desiredRole1", label: "第一意向岗位", aliases: ["意向岗位1", "第一意向岗位", "期望职位", "意向职位"] },
  { key: "desiredRole2", label: "第二意向岗位", aliases: ["意向岗位2", "第二意向岗位", "其他意向职位"] },
  { key: "desiredCity1", label: "第一意向城市", aliases: ["意向工作城市", "意向工作地1", "第一意向城市", "期望城市", "工作地点"] },
  { key: "desiredCity2", label: "第二意向城市", aliases: ["意向工作地2", "第二意向城市"] },
  { key: "acceptRoleAdjustment", label: "接受岗位调剂", options: COMMON_OPTIONS.yesNo, aliases: ["是否接受岗位调剂", "是否接受其他岗位调剂", "接受岗位调剂"] },
  { key: "acceptCityAdjustment", label: "接受城市调剂", options: COMMON_OPTIONS.yesNo, aliases: ["是否接受工作地调剂", "是否接受其他工作地调剂", "是否接受意向城市调剂"] },
  { key: "source", label: "招聘信息来源", options: COMMON_OPTIONS.source, aliases: ["招聘信息来源", "获知渠道", "信息来源"] },
  { key: "jobType", label: "求职类型", options: COMMON_OPTIONS.jobType, aliases: ["求职类型", "工作性质", "职位类型"] },
  { key: "availableDate", label: "可到岗日期", aliases: ["可到岗日期", "到岗时间", "入职时间"] },
  { key: "interests", label: "兴趣爱好", aliases: ["兴趣爱好", "爱好", "interests", "hobbies"] },
  { key: "languages", label: "语言能力", aliases: ["语言能力", "外语能力", "语言证书及成绩", "英语水平"] },
  { key: "certificates", label: "技能证书", aliases: ["技能证书", "资格证书", "证书"] },
  { key: "awards", label: "获奖经历", aliases: ["获奖经历", "荣誉奖项", "奖项", "荣誉"] },
  { key: "skills", label: "专业技能", aliases: ["专业技能", "技能特长", "计算机技能", "办公技能"] },
  { key: "campusExperience", label: "校园经历", aliases: ["校园经历", "校园工作经历", "社团经历", "学生工作"] },
  { key: "projectExperience", label: "项目经验", aliases: ["项目经验", "项目经历"] },
  { key: "publications", label: "论文与成果", aliases: ["论文", "论文期刊", "研究成果"] },
  { key: "selfEvaluation", label: "自我描述／自我评价", aliases: ["自我评价", "自我描述", "补充说明", "个人总结", "个人评价"] }
];

const DEFAULT_PROFILE = {
  version: PROFILE_VERSION,
  personal: {
    name: "", namePinyin: "", mobile: "", email: "", gender: "", birthDate: "",
    idType: "", idNumber: "", nativePlace: "", ethnicity: "", nationality: "", birthCountry: "",
    currentCountry: "", politicalStatus: "", maritalStatus: "", healthStatus: "", hukou: "",
    currentCity: "", address: "", wechat: "", emergencyContact: "", emergencyPhone: ""
  },
  preferences: {
    graduationYear: "", highestDegree: "", desiredRole1: "", desiredRole2: "",
    desiredCity1: "", desiredCity2: "", acceptRoleAdjustment: "",
    acceptCityAdjustment: "", source: "", jobType: "", availableDate: ""
  },
  education: [],
  experience: [],
  projects: [],
  awards: [],
  competitions: [],
  publications: [],
  extras: { interests: "", languages: "", certificates: "", awards: "", skills: "", campusExperience: "", projectExperience: "", publications: "", selfEvaluation: "" },
  resume: null,
  rawResumeText: "",
  updatedAt: ""
};

globalThis.JobAutofillSchema = { PROFILE_VERSION, COMMON_OPTIONS, FIELD_DEFINITIONS, DEFAULT_PROFILE };
