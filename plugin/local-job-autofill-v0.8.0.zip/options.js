(() => {
const { DEFAULT_PROFILE, FIELD_DEFINITIONS, COMMON_OPTIONS } = JobAutofillSchema;

const personalKeys = ["name", "namePinyin", "mobile", "email", "gender", "birthDate", "idType", "idNumber", "nativePlace", "ethnicity", "nationality", "birthCountry", "currentCountry", "politicalStatus", "maritalStatus", "healthStatus", "hukou", "currentCity", "address", "wechat", "emergencyContact", "emergencyPhone"];
const preferenceKeys = ["graduationYear", "highestDegree", "desiredRole1", "desiredRole2", "desiredCity1", "desiredCity2", "acceptRoleAdjustment", "acceptCityAdjustment", "source", "jobType", "availableDate"];
const extraKeys = ["interests", "languages", "certificates", "skills", "campusExperience", "projectExperience", "selfEvaluation"];
let profile = structuredClone(DEFAULT_PROFILE);

const $ = (selector) => document.querySelector(selector);
const definition = (key) => FIELD_DEFINITIONS.find((item) => item.key === key) || { key, label: key };

function inputTemplate(key, group) {
  const def = definition(key);
  const sensitive = def.sensitive ? '<span class="sensitive">敏感</span>' : "";
  const multiline = extraKeys.includes(key);
  const listId = def.options ? `choices-${group}-${key}` : "";
  return `<label class="field ${def.required ? "required" : ""}">
    <span>${def.label}${sensitive}</span>
    ${multiline
      ? `<textarea rows="3" data-group="${group}" data-key="${key}"></textarea>`
      : `<input data-group="${group}" data-key="${key}" type="${key === "birthDate" || key === "availableDate" ? "date" : "text"}" ${listId ? `list="${listId}"` : ""}>${def.options ? `<datalist id="${listId}">${def.options.map((value) => `<option value="${escapeHtml(value)}"></option>`).join("")}</datalist>` : ""}`}
  </label>`;
}

function renderStaticFields() {
  $("#personalFields").innerHTML = personalKeys.map((key) => inputTemplate(key, "personal")).join("");
  $("#preferenceFields").innerHTML = preferenceKeys.map((key) => inputTemplate(key, "preferences")).join("");
  $("#extraFields").innerHTML = extraKeys.map((key) => inputTemplate(key, "extras")).join("");
}

function entryControl(type, index, key, value, options = null, multiline = false) {
  const attrs = `data-entry="${type}" data-index="${index}" data-key="${key}"`;
  if (multiline) return `<textarea rows="4" ${attrs}>${escapeHtml(value || "")}</textarea>`;
  const listId = options ? `choices-${type}-${index}-${key}` : "";
  return `<input type="text" ${attrs} value="${escapeHtml(value || "")}" ${listId ? `list="${listId}"` : ""}>${options ? `<datalist id="${listId}">${options.map((option) => `<option value="${escapeHtml(option)}"></option>`).join("")}</datalist>` : ""}`;
}

function entryTemplate(type, item, index) {
  const configs = {
    education: {
      title: "教育经历", wide: false,
      fields: [["school", "学校"], ["department", "院系"], ["major", "专业"], ["degree", "学历", COMMON_OPTIONS.degree], ["startDate", "开始时间（YYYY.MM）"], ["endDate", "结束时间（YYYY.MM/至今）"], ["educationType", "学历类型", COMMON_OPTIONS.educationType], ["studyMode", "学习形式", COMMON_OPTIONS.studyMode], ["isHighest", "是否最高学历", COMMON_OPTIONS.yesNo], ["gpa", "GPA"], ["averageScore", "平均分"], ["rank", "成绩排名", COMMON_OPTIONS.rank], ["courses", "主修／核心课程", null, true], ["scholarship", "奖学金／校内荣誉"], ["research", "研究方向"], ["labExperience", "是否有实验室经历", COMMON_OPTIONS.yesNo], ["description", "教育经历补充", null, true]]
    },
    experience: {
      title: "实习／工作经历", wide: true,
      fields: [["type", "经历类型", COMMON_OPTIONS.experienceType], ["company", "单位"], ["department", "部门"], ["role", "职位（自动提取，可选）"], ["startDate", "开始时间（YYYY.MM）"], ["endDate", "结束时间（YYYY.MM/至今）"], ["description", "工作介绍／职责与成果（主要填写）", null, true]]
    },
    projects: {
      title: "项目经历", wide: true,
      fields: [["name", "项目名称"], ["role", "项目职责"], ["startDate", "开始时间（YYYY.MM）"], ["endDate", "结束时间（YYYY.MM/至今）"], ["description", "项目描述", null, true], ["outcome", "项目成果", null, true]]
    },
    awards: {
      title: "荣誉奖项", wide: true,
      fields: [["date", "获得时间（YYYY/MM）"], ["name", "名称"], ["result", "成绩／等级", COMMON_OPTIONS.awardResult], ["type", "类型", COMMON_OPTIONS.awardType], ["description", "描述", null, true]]
    },
    competitions: {
      title: "竞赛经历", wide: true,
      fields: [["startDate", "开始／获得时间（YYYY/MM）"], ["endDate", "结束时间（YYYY/MM，可不填）"], ["name", "名称"], ["result", "成绩／名次", COMMON_OPTIONS.awardResult], ["type", "类型", COMMON_OPTIONS.competitionType], ["description", "描述", null, true]]
    },
    publications: {
      title: "论文", wide: true,
      fields: [["name", "名称"], ["type", "类型", COMMON_OPTIONS.publicationType], ["authorOrder", "作者顺序", COMMON_OPTIONS.authorOrder], ["publishDate", "发表时间（YYYY/MM/DD 或 YYYY/MM）"], ["link", "论文链接"], ["description", "论文描述", null, true]]
    }
  };
  const config = configs[type];
  return `<div class="repeat-card" data-type="${type}" data-index="${index}">
    <div class="repeat-title"><strong>${config.title} ${index + 1}</strong><div class="row-actions"><button type="button" class="move" data-move="up" data-type-name="${type}" data-index="${index}" aria-label="上移">↑</button><button type="button" class="move" data-move="down" data-type-name="${type}" data-index="${index}" aria-label="下移">↓</button><button type="button" class="remove" data-remove="${type}" data-index="${index}">删除</button></div></div>
    <div class="field-grid ${config.wide ? "wide" : ""}">
      ${config.fields.map(([key, label, options, multiline]) => `<label class="field"><span>${label}</span>${entryControl(type, index, key, item[key], options, multiline)}</label>`).join("")}
    </div>
  </div>`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[char]));
}

function renderRepeats() {
  $("#educationList").innerHTML = profile.education.map((item, i) => entryTemplate("education", item, i)).join("");
  $("#experienceList").innerHTML = profile.experience.map((item, i) => entryTemplate("experience", item, i)).join("");
  $("#projectList").innerHTML = profile.projects.map((item, i) => entryTemplate("projects", item, i)).join("");
  $("#awardList").innerHTML = profile.awards.map((item, i) => entryTemplate("awards", item, i)).join("");
  $("#competitionList").innerHTML = profile.competitions.map((item, i) => entryTemplate("competitions", item, i)).join("");
  $("#publicationList").innerHTML = profile.publications.map((item, i) => entryTemplate("publications", item, i)).join("");
}

function populateForm() {
  document.querySelectorAll("[data-group][data-key]").forEach((input) => {
    input.value = profile[input.dataset.group]?.[input.dataset.key] || "";
  });
  renderRepeats();
  updateMissing();
}

function collectForm() {
  document.querySelectorAll("[data-group][data-key]").forEach((input) => {
    profile[input.dataset.group][input.dataset.key] = input.value.trim();
  });
  document.querySelectorAll("[data-entry]").forEach((input) => {
    profile[input.dataset.entry][Number(input.dataset.index)][input.dataset.key] = input.value.trim();
  });
  profile.updatedAt = new Date().toISOString();
}

function updateMissing() {
  collectForm();
  const important = ["name", "mobile", "email", "gender", "birthDate", "graduationYear", "highestDegree", "desiredCity1"];
  const values = { ...profile.personal, ...profile.preferences, ...profile.extras };
  let count = 0;
  important.forEach((key) => {
    const input = document.querySelector(`[data-key="${key}"]`);
    const missing = !values[key];
    input?.closest(".field")?.classList.toggle("missing", missing);
    if (missing) count += 1;
  });
  $("#missingCount").textContent = count ? `${count} 个常用字段待补` : "常用字段已齐";
}

function normalizeText(text) {
  return String(text || "").normalize("NFKC").replace(/\r\n?/g, "\n").replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

function repairExtractedText(text) {
  const headings = ["教育背景", "教育经历", "实习经历", "工作经历", "项目经历", "项目经验", "校园经历", "社团经历", "荣誉奖项", "获奖经历", "竞赛经历", "论文期刊", "技能证书", "自我评价", "自我描述"];
  const radicalMap = { "⽉": "月", "⼿": "手", "⼤": "大", "⼠": "士", "⺠": "民", "⼒": "力", "⽤": "用", "⼀": "一", "⼩": "小", "⾏": "行", "⽅": "方", "⽂": "文", "⼈": "人", "⻔": "门", "⻓": "长", "⻛": "风", "⾃": "自", "⽣": "生" };
  let repaired = normalizeText(text).replace(/[⽉⼿⼤⼠⺠⼒⽤⼀⼩⾏⽅⽂⼈⻔⻓⻛⾃⽣]/g, (char) => radicalMap[char] || char).replace(/[‐‑‒–—―~～]/g, "-").replace(/[／]/g, "/").replace(/[：]/g, ":").replace(/[＠]/g, "@");
  repaired = repaired.split("\n").map((rawLine) => {
    let line = rawLine;
    let previous;
    do {
      previous = line;
      line = line.replace(/([\u3400-\u9fff])\s+(?=[\u3400-\u9fff])/g, "$1");
    } while (line !== previous);
    line = line.replace(/\s*([.@/_:+-])\s*/g, "$1");
    line = line.replace(/(?:\d[\s-]*){10,15}/g, (candidate) => {
      const digits = candidate.replace(/\D/g, "");
      return /^1[3-9]\d{9}$/.test(digits) ? digits : candidate;
    });
    line = line.replace(/[A-Z0-9._%+-]+(?:\s+[A-Z0-9._%+-]+)*\s*@\s*[A-Z0-9.-]+(?:\s+[A-Z0-9.-]+)*\s*\.\s*[A-Z]{2,}/gi, (candidate) => candidate.replace(/\s+/g, ""));
    return line.trim();
  }).join("\n");
  for (const heading of headings) {
    const spaced = [...heading].join("\\s*");
    repaired = repaired.replace(new RegExp(`\\s*${spaced}\\s*`, "g"), `\n${heading}\n`);
  }
  return normalizeText(repaired);
}

function analyzeExtractedText(text) {
  const normalized = repairExtractedText(text);
  const compact = normalized.replace(/\s+/g, "");
  const signals = [];
  if (/1[3-9]\d{9}/.test(compact)) signals.push("手机号");
  if (/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(compact)) signals.push("邮箱");
  if (/(?:大学|学院|学校)/.test(normalized)) signals.push("学校");
  if (/(?:教育背景|教育经历|实习经历|工作经历|项目经历|项目经验)/.test(normalized)) signals.push("章节标题");
  if (/20\d{2}[.年/-]\d{1,2}/.test(normalized)) signals.push("日期");
  const cjk = normalized.match(/[\u3400-\u9fff]/g) || [];
  const frequency = new Map();
  cjk.forEach((char) => frequency.set(char, (frequency.get(char) || 0) + 1));
  const highest = Math.max(0, ...frequency.values());
  const repeatedRatio = cjk.length ? highest / cjk.length : 0;
  const replacementRatio = normalized.length ? (normalized.match(/[�□]/g) || []).length / normalized.length : 0;
  let warning = "";
  if (!normalized || normalized.length < 20) warning = "提取到的文字过少，可能是扫描版 PDF。";
  else if ((cjk.length >= 30 && frequency.size <= 6 && repeatedRatio >= 0.5) || replacementRatio > 0.04) warning = "PDF 有文字层，但字体的字符映射异常，无法可靠还原原文。";
  else if (!signals.length) warning = "已提取文字，但没有识别到常见的简历字段；请查看下方文本预览。";
  return { text: normalized, length: normalized.length, signals, warning };
}

function makeExtractionError(message, extractedText = "") {
  const error = new Error(message);
  error.extractedText = extractedText;
  return error;
}

async function docxToText(file) {
  const zip = await JSZip.loadAsync(await file.arrayBuffer());
  const xml = await zip.file("word/document.xml")?.async("string");
  if (!xml) throw new Error("不是有效的 DOCX 文件");
  const documentXml = new DOMParser().parseFromString(xml, "application/xml");
  const paragraphs = [...documentXml.getElementsByTagNameNS("*", "p")];
  return normalizeText(paragraphs.map((p) => [...p.getElementsByTagNameNS("*", "t")].map((t) => t.textContent).join("")).filter(Boolean).join("\n"));
}

let pdfModulePromise;
async function pdfToText(file) {
  pdfModulePromise ||= import(chrome.runtime.getURL("vendor/pdf.min.mjs"));
  const pdfjs = await pdfModulePromise;
  pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("vendor/pdf.worker.min.mjs");
  const pdf = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  const rowPages = [];
  const columnPages = [];
  const embeddedPages = [];
  const layoutPages = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 1 });
    const content = await page.getTextContent();
    const visualLines = [];
    for (const item of content.items) {
      if (!(item.str || "").trim()) continue;
      const x = Number(item.transform?.[4] || 0);
      const y = Number(item.transform?.[5] || 0);
      const height = Math.abs(Number(item.height || item.transform?.[3] || 10));
      const tolerance = Math.max(2, Math.min(5, height * 0.35));
      let line = visualLines.find((candidate) => Math.abs(candidate.y - y) <= Math.max(candidate.tolerance, tolerance));
      if (!line) { line = { y, tolerance, items: [] }; visualLines.push(line); }
      line.items.push({ text: item.str, x, width: Number(item.width || 0), fontSize: height });
      line.y = (line.y * (line.items.length - 1) + y) / line.items.length;
    }
    visualLines.sort((a, b) => b.y - a.y);
    const renderItems = (items) => {
      items = [...items].sort((a, b) => a.x - b.x);
      let rendered = "";
      let previous = null;
      for (const item of items) {
        if (previous) {
          const gap = item.x - (previous.x + previous.width);
          if (gap > Math.max(1.5, viewport.width * 0.003)) rendered += " ";
        }
        rendered += item.text;
        previous = item;
      }
      return rendered.trim();
    };
    const layoutLines = visualLines.map((line) => {
      const items = line.items.sort((a, b) => a.x - b.x);
      const chunks = [];
      let chunk = [];
      for (const item of items) {
        const previous = chunk.at(-1);
        const gap = previous ? item.x - (previous.x + previous.width) : 0;
        if (chunk.length && gap > Math.max(36, viewport.width * 0.075)) { chunks.push(chunk); chunk = []; }
        chunk.push(item);
      }
      if (chunk.length) chunks.push(chunk);
      const cells = chunks.map((itemsInCell) => ({
        text: repairExtractedText(renderItems(itemsInCell)),
        x: Math.min(...itemsInCell.map((item) => item.x)),
        fontSize: Math.max(...itemsInCell.map((item) => item.fontSize || 0))
      })).filter((cell) => cell.text);
      return { text: cells.map((cell) => cell.text).join(" | "), y: line.y, maxFontSize: Math.max(0, ...cells.map((cell) => cell.fontSize)), cells };
    }).filter((line) => line.text);
    const lines = layoutLines.map((line) => line.text);
    rowPages.push(lines.join("\n"));
    layoutPages.push({ pageNumber, width: viewport.width, height: viewport.height, lines: layoutLines });

    const midpoint = viewport.width / 2;
    const left = [];
    const right = [];
    for (const line of visualLines) {
      const leftItems = line.items.filter((item) => item.x < midpoint);
      const rightItems = line.items.filter((item) => item.x >= midpoint);
      if (leftItems.length) left.push(renderItems(leftItems));
      if (rightItems.length) right.push(renderItems(rightItems));
    }
    const rightCharacterCount = right.join("").length;
    columnPages.push(rightCharacterCount >= 40 ? `${left.filter(Boolean).join("\n")}\n${right.filter(Boolean).join("\n")}` : lines.join("\n"));
    embeddedPages.push(content.items.map((item) => item.str || "").filter(Boolean).join("\n"));
  }
  const candidates = [
    { name: "视觉逐行", text: repairExtractedText(rowPages.join("\n\n")), layout: layoutPages },
    { name: "分栏阅读", text: repairExtractedText(columnPages.join("\n\n")) },
    { name: "PDF内嵌顺序", text: repairExtractedText(embeddedPages.join("\n\n")) }
  ].filter((candidate, index, all) => candidate.text && all.findIndex((other) => other.text === candidate.text) === index);
  const diagnoses = candidates.map((candidate) => analyzeExtractedText(candidate.text));
  if (!candidates.length) throw makeExtractionError("PDF 中没有可提取文字；扫描版 PDF 暂不支持 OCR");
  if (diagnoses.every((diagnosis) => /字符映射异常/.test(diagnosis.warning))) throw makeExtractionError(`${diagnoses[0].warning}请尝试从 PDF 复制一段文字；若也是乱码，请另存为 DOCX 后导入。`, candidates[0].text);
  return { text: candidates[0].text, alternatives: candidates, pageCount: pdf.numPages };
}

function markdownToText(markdown) {
  return normalizeText(markdown
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+[.)]\s+/gm, "")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/[*_`>]/g, ""));
}

function usefulBinaryRuns(text) {
  const runs = text.match(/[\u3400-\u9fffA-Za-z0-9@._%+\-—–:/（）()，。；：、｜|\s]{4,}/g) || [];
  return runs.map((run) => run.replace(/[\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim())
    .filter((run) => run.length >= 4 && /[\u3400-\u9fffA-Za-z0-9]/.test(run));
}

async function legacyDocToText(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const signature = [...bytes.slice(0, 8)].map((value) => value.toString(16).padStart(2, "0")).join("");
  if (signature !== "d0cf11e0a1b11ae1") throw new Error("文件不是有效的旧版 Word DOC");
  const candidates = [];
  for (const offset of [0, 1]) candidates.push(...usefulBinaryRuns(new TextDecoder("utf-16le", { fatal: false }).decode(bytes.subarray(offset))));
  candidates.push(...usefulBinaryRuns(new TextDecoder("windows-1252", { fatal: false }).decode(bytes)));
  const noise = /Microsoft|WordDocument|SummaryInformation|DocumentSummaryInformation|CompObj|Root Entry|Times New Roman|Calibri/i;
  const unique = [...new Set(candidates.filter((run) => !noise.test(run)))];
  let text = normalizeText(unique.join("\n"));
  const headings = ["教育背景", "教育经历", "实习经历", "工作经历", "项目经历", "项目经验", "社团及组织经历", "校园经历", "荣誉奖项", "获奖经历", "竞赛经历", "论文/期刊", "论文／期刊", "技能证书", "自我评价"];
  for (const heading of headings) text = text.replace(new RegExp(`\\s*${heading}\\s*`, "g"), `\n${heading}\n`);
  text = text.replace(/^(\s*[\u3400-\u9fff·]+(?:\s+[\u3400-\u9fff·]+){0,4})\s+(?=手机号|手机|电话|邮箱)/, "$1\n");
  text = normalizeText(text);
  if (text.length < 30) throw new Error("该 DOC 无法可靠提取；请用 Word 另存为 DOCX 后再导入");
  return text;
}

async function extractResumeText(file) {
  const extension = file.name.split(".").pop()?.toLowerCase();
  if (extension === "docx") { const text = await docxToText(file); return { text, alternatives: [{ name: "Word段落", text }] }; }
  if (extension === "pdf") return pdfToText(file);
  if (extension === "md" || file.type === "text/markdown") { const text = markdownToText(await file.text()); return { text, alternatives: [{ name: "Markdown正文", text }] }; }
  if (extension === "doc") { const text = await legacyDocToText(file); return { text, alternatives: [{ name: "DOC文字流", text }] }; }
  throw new Error("仅支持 DOC、DOCX、PDF 和 Markdown 文件");
}

function firstMatch(text, regex) {
  return text.match(regex)?.[1]?.trim() || "";
}

function splitLines(text) {
  return text.split(/\n/).map((line) => line.trim()).filter(Boolean);
}

const DATE_TOKEN_SOURCE = "(?:(?:19|20)\\d{4}|(?:19|20)\\d{2}\\s*(?:[.\\/-]\\s*\\d{1,2}|年\\s*\\d{1,2}\\s*月?)?|\\d{1,2}\\s*[.\\/-]\\s*(?:19|20)\\d{2}|\\d{2}\\s*[.\\/-]\\s*\\d{1,2})";
const CURRENT_DATE_SOURCE = "(?:至今|今|现在|目前|present|current|迄今)";

function normalizeDateToken(value, referenceYear = "") {
  let token = String(value || "").normalize("NFKC").trim();
  if (new RegExp(`^${CURRENT_DATE_SOURCE}$`, "i").test(token)) return "至今";
  token = token.replace(/\s+/g, "");
  if (/^(?:19|20)\d{4}$/.test(token)) token = `${token.slice(0, 4)}.${token.slice(4)}`;
  const monthFirst = token.match(/^(\d{1,2})[.\/-]((?:19|20)\d{2})$/);
  if (monthFirst) token = `${monthFirst[2]}.${monthFirst[1]}`;
  const shortYear = token.match(/^(\d{2})[.\/-](\d{1,2})$/);
  if (shortYear) token = `${String(referenceYear || "20").slice(0, 2)}${shortYear[1]}.${shortYear[2]}`;
  token = token.replace(/年/g, ".").replace(/月/g, "").replace(/[\/-]/g, ".").replace(/\.+/g, ".").replace(/\.$/, "");
  const match = token.match(/^((?:19|20)\d{2})(?:\.(\d{1,2}))?$/);
  if (!match) return "";
  if (!match[2]) return match[1];
  const month = Number(match[2]);
  return month >= 1 && month <= 12 ? `${match[1]}.${String(month).padStart(2, "0")}` : "";
}

function extractDateRange(text) {
  const original = String(text || "");
  const normalized = original.normalize("NFKC").replace(/(?<=[\d.\/-])[Oo](?=\d)/g, "0");
  const connector = "(?:-{1,3}|[—–−~～〜]|至|到|—?至—?|\\bto\\b|→|~)";
  let match = normalized.match(new RegExp(`(${DATE_TOKEN_SOURCE})\\s*${connector}\\s*(${DATE_TOKEN_SOURCE}|${CURRENT_DATE_SOURCE})`, "i"));
  let fuzzy = false;
  if (!match) {
    match = normalized.match(new RegExp(`(${DATE_TOKEN_SOURCE})\\s+(${DATE_TOKEN_SOURCE}|${CURRENT_DATE_SOURCE})`, "i"));
    fuzzy = Boolean(match);
  }
  if (!match) return null;
  const start = normalizeDateToken(match[1]);
  const end = normalizeDateToken(match[2], start);
  if (!start || !end) return null;
  return { raw: match[0], start, end, index: match.index || 0, confidence: fuzzy ? "fuzzy" : "exact" };
}

function extractSingleDate(text) {
  const normalized = String(text || "").normalize("NFKC").replace(/(?<=[\d.\/-])[Oo](?=\d)/g, "0");
  const match = normalized.match(new RegExp(`(${DATE_TOKEN_SOURCE})`, "i"));
  if (!match) return null;
  const start = normalizeDateToken(match[1]);
  return start ? { raw: match[0], start, end: "", index: match.index || 0, confidence: "single" } : null;
}

function looksLikeSectionHeading(line, pattern) {
  const compact = String(line || "").replace(/[\s|:：·•/／]/g, "");
  return compact.length <= 18 && pattern.test(compact);
}

function inferRoleFromDescription(description) {
  const text = String(description || "").replace(/\s+/g, " ");
  const labelled = text.match(/(?:担任|任职为|职位为|岗位为|作为)\s*([^,，;；。\n]{2,20}?(?:实习生|助理|专员|经理|主管|研究员|顾问|组长|负责人|律师|法务))/)?.[1];
  if (labelled) return labelled.trim();
  return text.match(/(?:法务实习生|律师助理|研究助理|产品实习生|运营实习生|审计实习生|咨询实习生|实习律师|项目助理|项目经理|研究员|组长|负责人)/)?.[0] || "";
}

function migrateProfile(saved = {}) {
  const legacyAwards = saved.extras?.awards ? [{ date: "", name: "", result: "", type: "", description: saved.extras.awards }] : [];
  const legacyPublications = saved.extras?.publications ? [{ name: "", type: "", authorOrder: "", publishDate: "", link: "", description: saved.extras.publications }] : [];
  return {
    ...structuredClone(DEFAULT_PROFILE), ...saved,
    personal: { ...DEFAULT_PROFILE.personal, ...(saved.personal || {}) },
    preferences: { ...DEFAULT_PROFILE.preferences, ...(saved.preferences || {}) },
    extras: { ...DEFAULT_PROFILE.extras, ...(saved.extras || {}) },
    education: Array.isArray(saved.education) ? saved.education : [],
    experience: Array.isArray(saved.experience) ? saved.experience : [],
    projects: Array.isArray(saved.projects) ? saved.projects : [],
    awards: Array.isArray(saved.awards) ? saved.awards : legacyAwards,
    competitions: Array.isArray(saved.competitions) ? saved.competitions : [],
    publications: Array.isArray(saved.publications) ? saved.publications : legacyPublications
  };
}

function layoutIdentityCandidates(layout) {
  const candidates = [];
  for (const page of layout || []) {
    for (const line of page.lines || []) {
      if (line.y < page.height * 0.62) continue;
      for (const cell of line.cells || []) {
        const compact = cell.text.replace(/\s+/g, "");
        if (/^[\u3400-\u9fff·]{2,4}$/.test(compact) && !/大学|学院|教育|背景|简历|求职/.test(compact)) candidates.push({ type: "chinese", value: compact, score: cell.fontSize * 10 - cell.x / page.width });
        if (/^[A-Za-z][A-Za-z .'-]{1,24}$/.test(cell.text.trim()) && !/phone|email|mobile|resume/i.test(cell.text)) candidates.push({ type: "english", value: cell.text.trim(), score: cell.fontSize * 10 - cell.x / page.width });
      }
    }
  }
  return candidates.sort((a, b) => b.score - a.score);
}

function parseResumeText(text, baseProfile = profile, context = {}) {
  text = repairExtractedText(text);
  const result = structuredClone(baseProfile);
  result.rawResumeText = text;
  const lines = splitLines(text);
  const fuzzyDateLines = lines.filter((line) => extractDateRange(line)?.confidence === "fuzzy");
  result.parseWarnings = fuzzyDateLines.map((line) => `日期为模糊识别，请核对：${line.slice(0, 80)}`);
  const contactLines = lines.map((line) => line.replace(/\s+/g, ""));
  result.personal.mobile ||= contactLines.map((line) => firstMatch(line, /(?<!\d)(1[3-9]\d{9})(?!\d)/)).find(Boolean) || "";
  result.personal.email ||= contactLines.map((line) => firstMatch(line, /([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i)).find(Boolean) || "";
  const identities = layoutIdentityCandidates(context.layout);
  result.personal.name ||= identities.find((candidate) => candidate.type === "chinese")?.value || "";
  result.personal.namePinyin ||= identities.find((candidate) => candidate.type === "english")?.value || "";
  if (!result.personal.name) {
    const headerMatch = text.match(/^([\u3400-\u9fff·](?:\s*[\u3400-\u9fff·]){1,5})\s*(?=手机|电话|邮箱)/);
    const candidate = headerMatch?.[1]?.replace(/\s+/g, "") || lines.map((line) => line.replace(/\s+/g, "")).find((line) => /^[\u4e00-\u9fa5·]{2,6}$/.test(line) && !/大学|学院|学校|教育|经历|背景|能力|评价/.test(line));
    if (candidate) result.personal.name = candidate;
  }
  if (!result.personal.namePinyin) result.personal.namePinyin = lines.slice(0, 10).find((line) => /^[A-Za-z][A-Za-z .'-]{1,24}$/.test(line) && !/resume|phone|email/i.test(line)) || "";
  result.preferences.desiredRole1 ||= firstMatch(text, /求职意向[:：|\s]*([^|\n]{2,20})/);
  const statedGraduation = text.match(/毕业时间[:：|\s]*(20\d{2})\s*年?\s*(\d{1,2})?\s*月?/);
  if (!result.preferences.graduationYear && statedGraduation) result.preferences.graduationYear = statedGraduation[1];
  const educationStart = lines.findIndex((line) => /教育背景|教育经历/.test(line));
  const educationBoundary = /个人能力|专业技能|实习经历|工作经历|工作经验|社会实践|项目经历|校园经历|荣誉奖项|获奖经历|竞赛经历|论文|自我评价/;
  const educationEnd = lines.findIndex((line, index) => index > educationStart && looksLikeSectionHeading(line, educationBoundary));
  const experienceStart = lines.findIndex((line) => /实习经历|工作经历|工作经验(?:和|与)?社会实践/.test(line));
  const experienceBoundary = /社团|校园经历|项目经历|技能证书|荣誉奖项|获奖经历|竞赛(?:和|与)?其他活动经历|竞赛经历|论文|自我评价/;
  const experienceEnd = lines.findIndex((line, index) => index > experienceStart && looksLikeSectionHeading(line, experienceBoundary));
  const educationLines = educationStart >= 0 ? lines.slice(educationStart + 1, educationEnd > educationStart ? educationEnd : undefined) : lines;
  const experienceLines = experienceStart >= 0 ? lines.slice(experienceStart + 1, experienceEnd > experienceStart ? experienceEnd : undefined) : lines;
  const seen = new Set(result.education.map((item) => `${item.school}-${item.startDate}`));
  educationLines.forEach((line, index) => {
    const schoolMatch = line.match(/([\u4e00-\u9fa5]{2,24}大学(?:[\u4e00-\u9fa5]{2,12}分校)?|[\u4e00-\u9fa5]{2,20}(?:学院|学校))/);
    if (!schoolMatch) return;
    const school = schoolMatch[1].replace(/^.*赴(?=[\u4e00-\u9fa5]{2,}(?:大学|学院)$)/, "");
    if (/全国大学|大学生|本人|课程|就读院校/.test(school)) return;
    const context = [line, educationLines[index + 1], educationLines[index + 2]].filter(Boolean).join(" ");
    const nextLineHasSchool = /[\u4e00-\u9fa5]{2,24}(?:大学|学院|学校)/.test(educationLines[index + 1] || "");
    const date = extractDateRange(line) || (!nextLineHasSchool ? extractDateRange(educationLines[index + 1]) : null);
    const exchangeDate = line.match(/(20\d{2})\s*年\s*(\d{1,2})\s*月?\s*至\s*(\d{1,2})\s*月/);
    const degree = /博士/.test(line) ? "博士" : /硕士|法律硕士/.test(line) ? "硕士" : /本科|学士/.test(line) ? "本科" : "";
    const lineParts = line.split("|").map((part) => part.trim());
    const explicitMajor = lineParts.find((part) => /^(?:法学|法律|法学研究|法律硕士|计算机|金融|会计|经济学|管理学)(?:专业)?$/.test(part))?.replace(/专业$/, "") || "";
    const major = explicitMajor || (/交换/.test(line) ? "" : (/法学/.test(context) || /法学实验班/.test(text) ? "法学" : /法律/.test(context) ? "法律" : ""));
    const department = line.includes("法学院") ? "法学院" : (line.split("|").map((part) => part.trim()).find((part) => /^[\u4e00-\u9fa5]{2,12}学院$/.test(part)) || "");
    const graduationDate = /届|本科/.test(line) && statedGraduation ? `${statedGraduation[1]}.${String(statedGraduation[2] || "06").padStart(2, "0")}` : "";
    const inlineExchange = /赴.+(?:大学|学院).*交换/.test(line) && !line.includes("|");
    const nextEducationIndex = educationLines.findIndex((candidate, candidateIndex) => candidateIndex > index && /[\u4e00-\u9fa5]{2,24}(?:大学|学院|学校)/.test(candidate) && !(/赴.+(?:大学|学院).*交换/.test(candidate) && !candidate.includes("|")));
    const detailLines = inlineExchange ? [] : educationLines.slice(index + 1, nextEducationIndex > index ? nextEducationIndex : undefined);
    const details = detailLines.join("\n");
    const gpa = firstMatch(details, /GPA\s*[:：]?\s*([0-9.]+(?:\s*\/\s*[0-9.]+)?)/i);
    const averageScore = firstMatch(details, /(?:课程均分|平均分|加权平均分)\s*[:：]?\s*([0-9.]+)/);
    const rank = firstMatch(details, /(年级前\s*\d+%|专业前\s*\d+%|前\s*\d+%)/).replace(/\s+/g, "");
    const courseStart = detailLines.findIndex((detail) => /(?:已修课程|主修课程|核心课程|修读课程)[:：]/.test(detail));
    const courses = courseStart >= 0 ? detailLines.slice(courseStart, detailLines.findIndex((detail, detailIndex) => detailIndex > courseStart && /GPA|奖学金|托福|雅思|四六级/.test(detail)) >= 0 ? detailLines.findIndex((detail, detailIndex) => detailIndex > courseStart && /GPA|奖学金|托福|雅思|四六级/.test(detail)) : courseStart + 2).join(" ").replace(/^.*?(?:已修课程|主修课程|核心课程|修读课程)[:：]/, "") : "";
    const scholarship = detailLines.find((detail) => /奖学金|优秀学生|三好学生|优秀毕业生/.test(detail))?.replace(/^[^\u3400-\u9fff]*/, "") || "";
    const item = { school, department: department === school ? "" : department, major, degree, startDate: date?.start || (exchangeDate ? `${exchangeDate[1]}.${String(exchangeDate[2]).padStart(2, "0")}` : ""), endDate: date?.end || (exchangeDate ? `${exchangeDate[1]}.${String(exchangeDate[3]).padStart(2, "0")}` : graduationDate), educationType: /交换/.test(line) ? "交换项目" : "", studyMode: /全日制/.test(line) ? "全日制" : /非全日制/.test(line) ? "非全日制" : "", isHighest: "", gpa, averageScore, rank, courses, scholarship, research: "", labExperience: "", description: details };
    const key = `${item.school}-${item.startDate}`;
    if (!seen.has(key)) { result.education.push(item); seen.add(key); }
  });
  const knownAwardsFromEducation = new Set(result.awards.map((item) => item.name));
  result.education.forEach((item) => {
    if (item.scholarship && !knownAwardsFromEducation.has(item.scholarship)) {
      const awardName = item.scholarship.replace(/^获得/, "");
      result.awards.push({ date: "", name: awardName, result: "", type: "奖学金", description: item.school ? `就读于${item.school}期间获得` : "" });
      knownAwardsFromEducation.add(awardName);
    }
  });
  if (!result.preferences.highestDegree) {
    const degrees = result.education.map((item) => item.degree);
    result.preferences.highestDegree = degrees.includes("博士") ? "博士" : degrees.includes("硕士") ? "硕士" : degrees.includes("本科") ? "本科" : "";
  }
  if (!result.preferences.graduationYear) {
    const years = result.education.filter((item) => item.degree).map((item) => item.endDate?.match(/^(20\d{2})/)?.[1]).filter(Boolean).map(Number);
    if (years.length) result.preferences.graduationYear = String(Math.max(...years));
  }
  const known = new Set(result.experience.map((item) => item.company));
  experienceLines.forEach((line, index) => {
    const orgMatch = line.match(/([\u4e00-\u9fa5A-Za-z（）()·]{2,50}?(?:律师事务所|有限公司|委员会|人民法院|法院|检察院|研究院|中心|协会))/);
    const date = extractDateRange(line) || extractDateRange(experienceLines[index + 1]);
    const socialPractice = !orgMatch && date && /调研|实践|志愿|大赛/.test(line);
    if (!orgMatch && !socialPractice) return;
    const socialParts = line.replace(date?.raw || "", "").split("|").map((part) => part.replace(/^[\s·•,“”'「」-]+|[\s·•,“”'「」-]+$/g, "")).filter(Boolean);
    const company = (orgMatch?.[1] || socialParts[0] || "").replace(/[“”'「」]/g, "");
    if (known.has(company)) return;
    const remainder = orgMatch ? line.slice((orgMatch.index || 0) + orgMatch[1].length) : line.slice((line.indexOf(company) || 0) + company.length);
    const cleanedRemainder = (socialPractice ? socialParts.slice(1).join(" | ") : remainder).replace(/^[|\s,，;；:-]+|[|\s,，;；:-]+$/g, "");
    const remainderParts = cleanedRemainder.split("|").map((part) => part.trim()).filter(Boolean);
    const inferredDepartment = remainderParts.length > 1 ? remainderParts[0] : (cleanedRemainder.match(/^([\u4e00-\u9fa5A-Za-z]{2,15}(?:部|庭|组|科|处|中心|团队))/)?.[1] || "");
    let role = remainderParts.length > 1 ? remainderParts.slice(1).join(" | ") : cleanedRemainder.slice(inferredDepartment.length).trim();
    let workSummary = "";
    if (role.length > 16 || /[、,，]|审查|撰写|对接|整理|研究|分析|负责.+等/.test(role)) { workSummary = role; role = ""; }
    const following = [];
    const descriptionStart = date && !extractDateRange(line) ? index + 2 : index + 1;
    for (let cursor = descriptionStart; cursor < experienceLines.length; cursor += 1) {
      if (extractDateRange(experienceLines[cursor]) || /(?:律师事务所|有限公司|委员会|人民法院|法院|检察院|研究院|中心|协会)/.test(experienceLines[cursor])) break;
      following.push(experienceLines[cursor].replace(/^[·•|\s]+/, ""));
    }
    if (workSummary) following.unshift(workSummary);
    const description = following.join("\n");
    role ||= inferRoleFromDescription(description);
    result.experience.push({ type: socialPractice ? "其他" : "实习", company, department: inferredDepartment, role, startDate: date?.start || "", endDate: date?.end || "", description });
    known.add(company);
  });
  const projectStart = lines.findIndex((line) => /项目经历|项目经验/.test(line));
  const projectEnd = lines.findIndex((line, index) => index > projectStart && looksLikeSectionHeading(line, /获奖|荣誉|技能|证书|语言|自我|竞赛|比赛|校园|社团/));
  if (projectStart >= 0) {
    const projectLines = lines.slice(projectStart + 1, projectEnd > projectStart ? projectEnd : undefined);
    for (let i = 0; i < projectLines.length; i += 1) {
      const date = extractDateRange(projectLines[i]);
      if (!date) continue;
      const parts = projectLines[i].replace(date.raw, "").split("|").map((part) => part.replace(/^[\s·•,，;；:-]+|[\s·•,，;；:-]+$/g, "")).filter(Boolean);
      const title = parts[0] || (projectLines[i + 1] && !extractDateRange(projectLines[i + 1]) ? projectLines[i + 1].replace(/^[·•\s]+/, "") : "");
      const role = parts.slice(1).join(" | ");
      const descriptionLines = [];
      for (let cursor = i + 1; cursor < projectLines.length; cursor += 1) {
        if (extractDateRange(projectLines[cursor])) break;
        if (projectLines[cursor] !== title) descriptionLines.push(projectLines[cursor].replace(/^[·•\s]+/, ""));
      }
      result.projects.push({ name: title, role, startDate: date.start, endDate: date.end, description: descriptionLines.join("\n"), outcome: "" });
    }
  }
  const sectionHeading = /教育背景|教育经历|个人能力|专业技能|实习经历|工作经历|工作经验|社会实践|项目经历|项目经验|社团|校园经历|荣誉奖项|获奖经历|竞赛(?:和|与)?其他活动经历|竞赛经历|比赛经历|论文|科研成果|技能证书|语言能力|自我评价|自我描述/;
  const sectionLines = (startPattern) => {
    const start = lines.findIndex((line) => startPattern.test(line));
    if (start < 0) return [];
    const end = lines.findIndex((line, index) => index > start && looksLikeSectionHeading(line, sectionHeading));
    return lines.slice(start + 1, end > start ? end : undefined);
  };
  const appendDatedEntries = (sourceLines, target, makeEntry) => {
    const seenEntries = new Set(target.map((entry) => `${entry.name}-${entry.date || entry.startDate || ""}`));
    sourceLines.forEach((line, index) => {
      const date = extractDateRange(line) || extractSingleDate(line);
      if (!date) return;
      let name = line.replace(date.raw, "").replace(/^[|·•,，;；:\s-]+|[|·•,，;；:\s-]+$/g, "");
      if (!name) name = sourceLines[index + 1] && !extractDateRange(sourceLines[index + 1]) && !extractSingleDate(sourceLines[index + 1]) ? sourceLines[index + 1] : "";
      const following = sourceLines.slice(index + 1, index + 4).filter((item) => !extractDateRange(item) && !extractSingleDate(item) && item !== name);
      const entry = makeEntry({ date, name, description: following.join("\n") });
      const key = `${entry.name}-${entry.date || entry.startDate || ""}`;
      if (entry.name && !seenEntries.has(key)) { target.push(entry); seenEntries.add(key); }
    });
  };
  appendDatedEntries(sectionLines(/荣誉奖项|获奖经历/), result.awards, ({ date, name, description }) => ({
    date: date.start, name, result: firstMatch(`${name} ${description}`, /(一等奖|二等奖|三等奖|金奖|银奖|铜奖|优秀奖|国家级|省级|校级)/), type: "", description
  }));
  appendDatedEntries(sectionLines(/竞赛(?:和|与)?其他活动经历|竞赛经历|比赛经历/), result.competitions, ({ date, name, description }) => ({
    startDate: date.start, endDate: date.end || "", name, result: firstMatch(`${name} ${description}`, /(一等奖|二等奖|三等奖|金奖|银奖|铜奖|冠军|亚军|季军|第\d+名)/), type: "", description
  }));
  const knownCompetitions = new Set(result.competitions.map((item) => `${item.name}-${item.startDate}`));
  lines.filter((line) => /(竞赛|大赛)/.test(line) && /奖/.test(line)).forEach((line) => {
    line.split(/[,，](?=\s*20\d{2}年)/).forEach((part) => {
      const year = part.match(/(20\d{2})年/)?.[1] || "";
      const awardResult = part.match(/((?:初赛|复赛|决赛)?(?:一等奖|二等奖|三等奖)|金奖|银奖|铜奖|优秀奖)/)?.[1] || "";
      const name = part.replace(/20\d{2}年/, "").replace(awardResult, "").replace(/[“”'「」]/g, "").replace(/^[\s]+|[\s。]+$/g, "");
      const key = `${name}-${year}`;
      if (name && !knownCompetitions.has(key)) {
        result.competitions.push({ startDate: year, endDate: "", name, result: awardResult, type: /英语|翻译/.test(name) ? "语言/翻译" : "其他", description: "" });
        knownCompetitions.add(key);
      }
    });
  });
  const activityLines = sectionLines(/竞赛(?:和|与)?其他活动经历|校园经历|社团经历/);
  const activityText = activityLines.join("").replace(/^获/, "");
  const activityResults = activityText.match(/第[一二三四五六七八九十\d]+届[^、，。\n]{1,36}?(?:冠军(?:暨总决赛最佳辩手)?|亚军|季军|最佳辩手|一等奖|二等奖|三等奖|优秀奖)/g) || [];
  activityResults.forEach((entryText) => {
    const resultText = entryText.match(/(冠军(?:暨总决赛最佳辩手)?|亚军|季军|最佳辩手|一等奖|二等奖|三等奖|优秀奖)$/)?.[1] || "";
    const name = entryText.slice(0, -resultText.length).replace(/^获/, "").trim();
    const key = `${name}-`;
    if (name && !knownCompetitions.has(key)) {
      result.competitions.push({ startDate: "", endDate: "", name, result: resultText, type: "文体竞赛", description: "" });
      knownCompetitions.add(key);
    }
  });
  activityLines.filter((line) => /竞赛|比赛|模拟法庭/.test(line) && !/(冠军|亚军|季军|等奖|优秀奖|雅思|托福|六级|语言技能)/.test(line)).forEach((line) => {
    const name = line.replace(/^[^\u3400-\u9fffA-Za-z]*/, "").replace(/^代表.*?参与/, "").trim();
    const key = `${name}-`;
    if (name && name.length <= 50 && !knownCompetitions.has(key)) {
      result.competitions.push({ startDate: "", endDate: "", name, result: "", type: /辩论|模拟法庭/.test(name) ? "文体竞赛" : "其他", description: "" });
      knownCompetitions.add(key);
    }
  });
  const publicationLines = sectionLines(/论文|科研成果/);
  if (publicationLines.length) {
    const knownPublications = new Set(result.publications.map((item) => item.name));
    publicationLines.forEach((line, index) => {
      if (line.length < 4 || /^(作者|关键词|摘要|链接)[:：]/.test(line) || /^https?:\/\//i.test(line)) return;
      const nextLine = publicationLines[index + 1] || "";
      const date = `${line} ${nextLine}`.match(/(?:19|20)\d{2}[.年/-]\d{1,2}(?:[.月/-]\d{1,2})?/);
      if (!date && !/[《》“”]/.test(line) && !/(论文|期刊|会议|journal|review)/i.test(line)) return;
      const link = [line, publicationLines[index + 1] || ""].join(" ").match(/https?:\/\/\S+/i)?.[0] || "";
      const name = line.replace(date?.[0] || "", "").replace(link, "").replace(/^[|·•,，;；:\s-]+|[|·•,，;；:\s-]+$/g, "");
      if (name && !knownPublications.has(name)) {
        result.publications.push({ name, type: "", authorOrder: "", publishDate: date?.[0] || "", link, description: publicationLines[index + 1] && publicationLines[index + 1] !== link ? publicationLines[index + 1] : "" });
        knownPublications.add(name);
      }
    });
  }
  const selfEvaluation = sectionLines(/自我评价|自我描述/).join("\n");
  if (selfEvaluation && !result.extras.selfEvaluation) result.extras.selfEvaluation = selfEvaluation;
  const abilityLines = sectionLines(/个人能力|专业技能/);
  if (!result.extras.skills && abilityLines.length) {
    result.extras.skills = abilityLines.filter((line) => !/(雅思|IELTS|六级|CET|竞赛|大赛).*(分|奖)/i.test(line)).map((line) => line.replace(/^[·•|\s]+/, "")).join("\n");
  }
  const campusLines = sectionLines(/校园经历|社团经历|竞赛(?:和|与)?其他活动经历/);
  if (!result.extras.campusExperience && campusLines.length) result.extras.campusExperience = campusLines.map((line) => line.replace(/^[·•|\s]+/, "")).join("\n");
  const english = text.match(/(?:雅思|IELTS)\s*[0-9.]+(?:\s*[（(][0-9.]+[）)])?|(?:托福|TOEFL)\s*[0-9]+(?:\s*分)?|(?:六级|CET-?6)\s*[0-9]+|(?:通过)?四六级(?:考试)?/gi);
  if (english?.length && !result.extras.languages) result.extras.languages = [...new Set(english)].join("；");
  result.competitions = result.competitions.filter((item) => !/语言技能|雅思|托福|六级/.test(item.name));
  if (/法律职业资格/.test(text) && !result.extras.certificates) result.extras.certificates = firstMatch(text, /(法律职业资格[^\n；。]*)/) || "法律职业资格证书";
  result.updatedAt = new Date().toISOString();
  return result;
}

function scoreResumeParse(parsed, text) {
  const filled = (object) => Object.values(object || {}).filter((value) => typeof value === "string" && value.trim()).length;
  const recordScore = (records, keys) => (records || []).reduce((sum, record) => sum + keys.filter((key) => record[key]?.trim()).length, 0);
  let score = filled(parsed.personal) * 3 + filled(parsed.preferences) * 2 + filled(parsed.extras);
  score += recordScore(parsed.education, ["school", "major", "degree", "startDate", "endDate"]) * 3;
  score += recordScore(parsed.experience, ["company", "role", "startDate", "endDate", "description"]) * 3;
  score += recordScore(parsed.projects, ["name", "role", "startDate", "endDate", "description"]) * 2;
  score += ((text.match(/教育背景|教育经历|实习经历|工作经历|项目经历|项目经验|荣誉奖项|竞赛经历|论文|自我评价/g) || []).length * 2);
  score -= (parsed.education || []).filter((item) => /全国大学|大学生|本人|课程|年/.test(item.school)).length * 15;
  if ((parsed.extras?.selfEvaluation || "").match(/\n(?:大学|学院|法院|协会|组长|实习|编辑)/g)?.length >= 2) score -= 20;
  return score;
}

function selectBestExtraction(extraction) {
  const candidates = extraction.alternatives?.length ? extraction.alternatives : [{ name: "正文顺序", text: extraction.text || "" }];
  const evaluated = candidates.map((candidate) => {
    const parsed = parseResumeText(candidate.text, structuredClone(DEFAULT_PROFILE), { layout: candidate.layout });
    return { ...candidate, score: scoreResumeParse(parsed, candidate.text) };
  }).sort((a, b) => b.score - a.score);
  return { selected: evaluated[0], evaluated };
}

function bufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(binary);
}

function showParseDiagnostics(diagnosis, format = "") {
  const details = $("#parseDetails");
  if (!diagnosis?.text && !diagnosis?.warning) { details.hidden = true; return; }
  const signalText = diagnosis.signals?.length ? `识别线索：${diagnosis.signals.join("、")}` : "未识别到常见简历线索";
  const strategyText = diagnosis.strategy ? ` · 采用：${diagnosis.strategy}` : "";
  const candidateText = diagnosis.candidates?.length > 1 ? ` · 比较了 ${diagnosis.candidates.length} 种阅读顺序` : "";
  $("#parseDiagnosis").textContent = `${format ? `${format.toUpperCase()} · ` : ""}${diagnosis.length || 0} 个字符${strategyText}${candidateText} · ${signalText}${diagnosis.warning ? `。${diagnosis.warning}` : ""}`;
  $("#parsePreview").textContent = (diagnosis.text || "（没有可预览文字）").slice(0, 6000);
  details.hidden = false;
  details.open = Boolean(diagnosis.warning);
}

async function handleResume(file) {
  if (!file) return;
  $("#resumeStatus").textContent = "正在本地解析…";
  try {
    const extraction = await extractResumeText(file);
    const { selected, evaluated } = selectBestExtraction(extraction);
    const text = selected.text;
    const extension = file.name.split(".").pop()?.toLowerCase() || "文件";
    const diagnosis = analyzeExtractedText(text);
    diagnosis.strategy = selected.name;
    diagnosis.candidates = evaluated.map(({ name, score }) => ({ name, score }));
    profile = parseResumeText(text, profile, { layout: selected.layout });
    if (profile.parseWarnings?.length) diagnosis.warning = [diagnosis.warning, ...profile.parseWarnings].filter(Boolean).join("；");
    profile.importDiagnostics = { ...diagnosis, format: extension, importedAt: new Date().toISOString() };
    profile.resume = { name: file.name, type: file.type || "application/vnd.openxmlformats-officedocument.wordprocessingml.document", size: file.size, data: bufferToBase64(await file.arrayBuffer()) };
    populateForm();
    showParseDiagnostics(diagnosis, extension);
    $("#resumeStatus").textContent = diagnosis.warning ? `已读取 ${file.name}，但需要检查解析结果` : `已读取 ${file.name}（未联网）`;
  } catch (error) {
    $("#resumeStatus").textContent = `读取失败：${error.message}`;
    showParseDiagnostics(analyzeExtractedText(error.extractedText || ""), file.name.split(".").pop()?.toLowerCase() || "文件");
  }
}

async function save() {
  collectForm();
  await chrome.storage.local.set({ jobAutofillProfile: profile });
  $("#saveStatus").textContent = `已保存到本机 · ${new Date().toLocaleTimeString()}`;
  updateMissing();
}

function downloadJson() {
  collectForm();
  const exportProfile = structuredClone(profile);
  if (exportProfile.resume) exportProfile.resume.data = "";
  const url = URL.createObjectURL(new Blob([JSON.stringify(exportProfile, null, 2)], { type: "application/json" }));
  const link = Object.assign(document.createElement("a"), { href: url, download: "秋招资料备份.json" });
  link.click(); URL.revokeObjectURL(url);
}

renderStaticFields();
chrome.storage.local.get("jobAutofillProfile").then(({ jobAutofillProfile }) => {
  if (jobAutofillProfile) profile = migrateProfile(jobAutofillProfile);
  populateForm();
  if (profile.resume?.name) $("#resumeStatus").textContent = `本机已保存：${profile.resume.name}`;
  if (profile.importDiagnostics) showParseDiagnostics(profile.importDiagnostics, profile.importDiagnostics.format);
});

$("#profileForm").addEventListener("input", updateMissing);
$("#resumeFile").addEventListener("change", (event) => handleResume(event.target.files[0]));
$("#saveButton").addEventListener("click", save);
$("#exportButton").addEventListener("click", downloadJson);
$("#importJson").addEventListener("change", async (event) => {
  try { profile = migrateProfile(JSON.parse(await event.target.files[0].text())); populateForm(); $("#saveStatus").textContent = "备份已载入，请检查后保存。"; }
  catch { $("#saveStatus").textContent = "备份文件格式不正确。"; }
});
$("#clearButton").addEventListener("click", async () => {
  if (!confirm("确定清空浏览器本地保存的全部求职资料吗？此操作不可撤销。")) return;
  await chrome.storage.local.remove("jobAutofillProfile"); profile = structuredClone(DEFAULT_PROFILE); populateForm(); $("#resumeStatus").textContent = "尚未读取"; showParseDiagnostics(null); $("#saveStatus").textContent = "本地资料已清空。";
});
document.body.addEventListener("click", (event) => {
  const add = event.target.dataset.add;
  if (add) {
    collectForm();
    const blank = {
      education: { school: "", department: "", major: "", degree: "", startDate: "", endDate: "", educationType: "", studyMode: "", isHighest: "", gpa: "", averageScore: "", rank: "", courses: "", scholarship: "", research: "", labExperience: "", description: "" },
      experience: { type: "实习", company: "", department: "", role: "", startDate: "", endDate: "", description: "" },
      projects: { name: "", role: "", startDate: "", endDate: "", description: "", outcome: "" },
      awards: { date: "", name: "", result: "", type: "", description: "" },
      competitions: { startDate: "", endDate: "", name: "", result: "", type: "", description: "" },
      publications: { name: "", type: "", authorOrder: "", publishDate: "", link: "", description: "" }
    };
    profile[add].push(blank[add]); renderRepeats();
  }
  const remove = event.target.dataset.remove;
  if (remove) { collectForm(); profile[remove].splice(Number(event.target.dataset.index), 1); renderRepeats(); }
  const direction = event.target.dataset.move;
  if (direction) {
    collectForm();
    const list = profile[event.target.dataset.typeName];
    const from = Number(event.target.dataset.index);
    const to = direction === "up" ? from - 1 : from + 1;
    if (to >= 0 && to < list.length) [list[from], list[to]] = [list[to], list[from]];
    renderRepeats();
  }
});
})();
