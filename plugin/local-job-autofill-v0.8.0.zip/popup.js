(() => {
const $ = (selector) => document.querySelector(selector);
let profile;

async function activeTab() {
  return (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
}

async function send(action) {
  const tab = await activeTab();
  if (!tab?.id || !/^https?:/.test(tab.url || "")) throw new Error("请先打开一个招聘网页");
  try {
    return await chrome.tabs.sendMessage(tab.id, { action, profile });
  } catch {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    return await chrome.tabs.sendMessage(tab.id, { action, profile });
  }
}

function showResult(message, isError = false) {
  $("#result").textContent = message;
  $("#result").classList.toggle("error", isError);
}

chrome.storage.local.get("jobAutofillProfile").then(({ jobAutofillProfile }) => {
  profile = jobAutofillProfile;
  if (!profile) {
    $("#profileSummary").innerHTML = "尚未建立本地资料。<br>请先打开资料库导入简历。";
    ["fillButton", "scanButton", "attachButton"].forEach((id) => $("#" + id).disabled = true);
    return;
  }
  const values = { ...profile.personal, ...profile.preferences, ...profile.extras };
  const completed = Object.values(values).filter(Boolean).length;
  $("#profileSummary").innerHTML = `<strong>${profile.personal?.name || "未填写姓名"}</strong><br>${completed} 个字段 · ${profile.education?.length || 0} 教育 · ${profile.experience?.length || 0} 实习/工作 · ${profile.projects?.length || 0} 项目 · ${profile.awards?.length || 0} 奖项 · ${profile.competitions?.length || 0} 竞赛 · ${profile.publications?.length || 0} 论文`;
  $("#attachButton").disabled = !profile.resume?.data;
});

$("#fillButton").addEventListener("click", async () => {
  try {
    const result = await send("fill");
    const labels = { education: "教育", experience: "实习/工作", projects: "项目", awards: "荣誉奖项", competitions: "竞赛", publications: "论文" };
    const shortRows = Object.entries(result.repeated || {}).filter(([, value]) => value.missingRows > 0).map(([key, value]) => `${labels[key]}少 ${value.missingRows} 行`);
    const addedRows = Object.entries(result.repeated || {}).filter(([, value]) => value.addedRows > 0).map(([key, value]) => `${labels[key]} ${value.addedRows} 行`);
    const blocked = Object.entries(result.repeated || {}).filter(([, value]) => value.addBlocked).map(([key]) => labels[key]);
    showResult(`已填写 ${result.filled} 项；${result.skipped} 项已有内容未覆盖。${addedRows.length ? ` 已自动新建：${addedRows.join("、")}。` : ""}${blocked.length ? ` 无法自动新建（可能是弹窗式）：${blocked.join("、")}。` : ""}${shortRows.length ? ` 仍缺记录：${shortRows.join("、")}。` : ""}${result.unmatched.length ? ` 未匹配：${result.unmatched.slice(0, 6).join("、")}` : ""}`);
  }
  catch (error) { showResult(error.message, true); }
});
$("#scanButton").addEventListener("click", async () => {
  try { const result = await send("scan"); showResult(result.missing.length ? `页面仍缺：${result.missing.slice(0, 12).join("、")}${result.missing.length > 12 ? "…" : ""}` : "当前可识别的必填项已填写。"); }
  catch (error) { showResult(error.message, true); }
});
$("#attachButton").addEventListener("click", async () => {
  if (!confirm("这会把本机保存的简历放入当前招聘网页的附件框，网站可能立即上传文件。是否继续？")) return;
  try { const result = await send("attachResume"); showResult(result.attached ? `已放入 ${profile.resume.name}。` : "未找到简历上传框，请手动选择文件。", !result.attached); }
  catch (error) { showResult(error.message, true); }
});
$("#openOptions").addEventListener("click", () => chrome.runtime.openOptionsPage());
})();
