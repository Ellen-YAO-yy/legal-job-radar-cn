(() => {
  if (globalThis.__localJobAutofillLoaded) return;
  globalThis.__localJobAutofillLoaded = true;

  const fieldAliases = {
    name: ["姓名", "中文名", "name"], namePinyin: ["姓名拼音", "拼音", "英文姓名"],
    mobile: ["手机", "手机号", "手机号码", "联系电话", "电话", "mobile", "phone"],
    email: ["邮箱", "电子邮箱", "电子邮件", "email"], gender: ["性别", "gender"],
    birthDate: ["出生日期", "出生年月", "生日", "birth date"], idType: ["证件类型", "证件类别"], idNumber: ["身份证", "身份证号", "证件号码", "证件号"],
    nativePlace: ["籍贯"], ethnicity: ["民族"], nationality: ["国籍"], birthCountry: ["出生国家", "出生地国家"],
    currentCountry: ["当前所在国家", "现居国家"], politicalStatus: ["政治面貌"], maritalStatus: ["婚姻状况", "婚姻状态"], healthStatus: ["健康状况", "身体状况"],
    hukou: ["户籍所在地", "户口所在地", "户籍"], currentCity: ["当前所在城市", "现居城市", "目前所在城市"], address: ["联系地址", "通讯地址", "现居地址", "家庭地址"],
    wechat: ["微信号", "微信", "wechat"], emergencyContact: ["紧急联系人", "应急联系人"], emergencyPhone: ["紧急联系人电话", "应急联系电话"], graduationYear: ["毕业年份", "毕业年度"],
    highestDegree: ["最高学历"], desiredRole1: ["意向岗位1", "第一意向岗位", "期望职位", "意向职位"],
    desiredRole2: ["意向岗位2", "第二意向岗位", "其他意向职位"], desiredCity1: ["意向工作城市", "意向工作地1", "第一意向城市", "期望城市", "工作地点"],
    desiredCity2: ["意向工作地2", "第二意向城市"], acceptRoleAdjustment: ["是否接受岗位调剂", "是否接受其他岗位调剂", "接受岗位调剂"],
    acceptCityAdjustment: ["是否接受工作地调剂", "是否接受其他工作地调剂", "是否接受意向城市调剂"],
    source: ["招聘信息来源", "获知渠道", "信息来源"], jobType: ["求职类型", "工作性质", "职位类型"], availableDate: ["可到岗日期", "到岗时间", "入职时间"], interests: ["兴趣爱好", "爱好"], languages: ["语言能力", "外语能力", "语言证书及成绩", "英语水平"],
    certificates: ["技能证书", "资格证书", "证书"], awards: ["获奖经历", "荣誉奖项", "奖项", "荣誉"],
    skills: ["专业技能", "技能特长", "计算机技能", "办公技能"], campusExperience: ["校园经历", "校园工作经历", "社团经历", "学生工作"],
    projectExperience: ["项目经验", "项目经历"], publications: ["论文", "论文期刊", "研究成果"], selfEvaluation: ["自我评价", "自我描述", "补充说明", "个人总结", "个人评价"]
  };

  const blockedWords = ["验证码", "captcha", "短信码", "校验码", "密码", "password", "推荐码", "邀请码"];
  const actionWords = ["提交", "预览", "下一步", "确认声明", "本人承诺", "同意", "授权"];
  const repeatSchemas = {
    education: {
      headings: ["教育背景", "教育经历"],
      fields: {
        school: ["学校名称", "学校", "毕业院校"], department: ["学院／系", "学院/系", "院系", "学院"], major: ["专业名称", "专业"],
        degree: ["学历", "学位"], startDate: ["入学时间", "开始时间", "起始时间"], endDate: ["毕业时间", "结束时间", "截止时间"], educationType: ["学历类型", "教育类型"], studyMode: ["学习形式", "培养方式"],
        isHighest: ["是否最高学历", "最高学历"], gpa: ["GPA", "平均绩点", "绩点"], averageScore: ["平均分", "加权平均分", "课程均分"], rank: ["成绩排名", "专业排名", "年级排名"], courses: ["主修课程", "核心课程", "已修课程"], scholarship: ["奖学金", "校内荣誉"], research: ["研究方向"], labExperience: ["是否有实验室经历", "实验室经历"], description: ["教育经历描述", "教育经历补充", "其他说明"]
      }
    },
    experience: {
      headings: ["实习经历", "工作经历", "实习／工作经历", "实习/工作经历"],
      fields: { company: ["公司名称", "单位名称", "公司", "单位"], department: ["部门名称", "部门", "所属部门"], role: ["职位名称", "职位", "岗位", "担任角色"], startDate: ["入职时间", "开始时间", "起始时间"], endDate: ["离职时间", "结束时间", "截止时间"], description: ["经历描述及成果", "工作介绍", "工作概括", "工作职责", "职责与成果", "工作内容"] }
    },
    projects: {
      headings: ["项目经历", "项目经验"],
      fields: { name: ["项目名称"], role: ["项目中职责", "项目职责", "担任角色"], startDate: ["开始时间", "项目开始时间"], endDate: ["结束时间", "项目结束时间"], description: ["项目描述", "项目描述及成果"], outcome: ["项目成果", "成果"] }
    },
    awards: {
      headings: ["荣誉奖项", "获奖经历", "荣誉奖项（含奖学金）"],
      fields: { date: ["获奖时间", "获得时间", "取得时间"], name: ["奖项名称", "荣誉名称"], result: ["奖项成绩", "成绩", "等级"], type: ["奖项类型", "类型"], description: ["奖项描述", "描述"] }
    },
    competitions: {
      headings: ["竞赛", "竞赛经历", "比赛经历"],
      fields: { name: ["竞赛名称", "比赛名称"], startDate: ["开始时间", "参赛时间", "获奖时间"], endDate: ["结束时间"], result: ["竞赛成绩", "比赛成绩", "成绩", "名次"], type: ["竞赛类型", "比赛类型", "类型"], description: ["竞赛描述", "比赛描述", "描述"] }
    },
    publications: {
      headings: ["论文", "论文/期刊", "论文／期刊"],
      fields: { name: ["论文名称", "名称"], type: ["论文类型", "类型"], authorOrder: ["作者顺序", "作者排名"], publishDate: ["发表时间", "发布时间"], link: ["论文链接", "链接"], description: ["论文描述", "描述"] }
    }
  };
  const allSectionHeadings = Object.values(repeatSchemas).flatMap((schema) => schema.headings).concat(["获奖经历", "语言能力", "自我描述", "论文", "技能证书", "校园工作经历"]);

  function normalize(value) { return String(value || "").toLowerCase().replace(/[\s*：:()（）\/_-]/g, ""); }
  function isVisible(el) { const style = getComputedStyle(el); const rect = el.getBoundingClientRect(); return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0; }
  function labelText(el) {
    const parts = [];
    if (el.labels) parts.push(...[...el.labels].map((label) => label.innerText));
    const id = el.id && CSS.escape(el.id);
    if (id) parts.push(...[...document.querySelectorAll(`label[for="${id}"]`)].map((label) => label.innerText));
    let node = el;
    for (let i = 0; node && i < 4; i += 1, node = node.parentElement) {
      parts.push(node.getAttribute?.("aria-label"), node.getAttribute?.("data-field"));
      const ownText = [...(node.childNodes || [])].filter((child) => child.nodeType === Node.TEXT_NODE).map((child) => child.textContent).join(" ").trim();
      if (ownText && ownText.length < 100) parts.push(ownText);
      const siblings = [...(node.children || [])].filter((child) => !child.contains(el) && !child.matches("input,textarea,select") && !child.querySelector?.("input,textarea,select"));
      for (const sibling of siblings.slice(0, 3)) {
        const text = sibling.textContent?.trim();
        if (text && text.length < 100) parts.push(text);
      }
    }
    parts.push(el.name, el.id, el.placeholder, el.getAttribute("aria-label"));
    return parts.filter(Boolean).join(" ").slice(0, 500);
  }

  function flatten(profile) { return { ...(profile.personal || {}), ...(profile.preferences || {}), ...(profile.extras || {}) }; }
  function matchKey(text) {
    const target = normalize(text);
    if (!target || blockedWords.some((word) => target.includes(normalize(word))) || actionWords.some((word) => target === normalize(word))) return null;
    let best = null;
    for (const [key, aliases] of Object.entries(fieldAliases)) {
      for (const alias of aliases) {
        const token = normalize(alias);
        if (target.includes(token) && (!best || token.length > best.length)) best = { key, length: token.length };
      }
    }
    return best?.key || null;
  }

  function currentValue(el) {
    if (el.type === "checkbox" || el.type === "radio") return el.checked ? el.value || "checked" : "";
    return el.value || el.textContent?.trim() || "";
  }

  function setNativeValue(el, value) {
    if (!value || !isVisible(el) || el.disabled || el.readOnly) return false;
    if (["checkbox", "radio", "file", "hidden", "submit", "button"].includes(el.type)) return false;
    if (el.type === "date") value = String(value).replace(/[./年]/g, "-").replace(/月|日/g, "").replace(/-+$/g, "");
    if (el.tagName === "SELECT") {
      const option = [...el.options].find((item) => normalize(item.text).includes(normalize(value)) || normalize(item.value) === normalize(value));
      if (!option) return false;
      el.value = option.value;
    } else {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      setter ? setter.call(el, value) : (el.value = value);
    }
    ["input", "change", "blur"].forEach((type) => el.dispatchEvent(new Event(type, { bubbles: true })));
    return true;
  }

  function directText(el) {
    return [...el.childNodes].filter((node) => node.nodeType === Node.TEXT_NODE).map((node) => node.textContent).join(" ").trim();
  }

  function findHeading(aliases) {
    const wanted = aliases.map(normalize);
    return [...document.querySelectorAll("h1,h2,h3,h4,h5,legend,section>div,form>div,div,span,p")]
      .filter(isVisible)
      .find((el) => wanted.includes(normalize(directText(el) || (el.children.length === 0 ? el.textContent : ""))));
  }

  function isAfter(a, b) { return Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING); }

  function sectionBounds(schema) {
    const heading = findHeading(schema.headings);
    if (!heading) return { heading: null, end: null };
    const laterHeadings = allSectionHeadings.map((name) => findHeading([name])).filter((candidate) => candidate && candidate !== heading && isAfter(heading, candidate));
    laterHeadings.sort((a, b) => isAfter(a, b) ? -1 : 1);
    return { heading, end: laterHeadings[0] || null };
  }

  function elementsForSection(schema, selector) {
    const { heading, end } = sectionBounds(schema);
    if (!heading) return [];
    return [...document.querySelectorAll(selector)].filter((element) => isVisible(element) && isAfter(heading, element) && (!end || isAfter(element, end)));
  }

  function controlsForSection(schema) {
    return elementsForSection(schema, "input,textarea,select");
  }

  function aliasesMatch(control, aliases) {
    const text = normalize(labelText(control));
    return aliases.some((alias) => text.includes(normalize(alias)));
  }

  async function tryCustomDropdown(el, value) {
    const looksCustom = el.tagName !== "SELECT" && (el.getAttribute("role") === "combobox" || el.hasAttribute("aria-haspopup") || /请选择|选择/.test(el.placeholder || "") || el.readOnly);
    if (!looksCustom) return false;
    el.click();
    await new Promise((resolve) => setTimeout(resolve, 120));
    const candidates = [...document.querySelectorAll("[role='option'],li,[class*='option'],[class*='menu-item'],[class*='select-item']")]
      .filter(isVisible)
      .filter((option) => normalize(option.textContent) === normalize(value));
    if (candidates.length !== 1) return false;
    candidates[0].click();
    await new Promise((resolve) => setTimeout(resolve, 60));
    return true;
  }

  async function fillControl(el, value) {
    if (await tryCustomDropdown(el, value)) return true;
    return setNativeValue(el, value);
  }

  function dateParts(value) {
    const match = String(value || "").match(/(20\d{2})[.年/-](\d{1,2})/);
    return match ? [match[1], String(Number(match[2]))] : [];
  }

  function meaningfulItems(type, items = []) {
    const identifyingKeys = {
      education: ["school", "major"], experience: ["company", "role"], projects: ["name"],
      awards: ["name"], competitions: ["name"], publications: ["name"]
    };
    return items.filter((item) => (identifyingKeys[type] || Object.keys(item)).some((key) => String(item?.[key] || "").trim()));
  }

  function primaryRowCount(type) {
    const schema = repeatSchemas[type];
    const primaryKey = { education: "school", experience: "company", projects: "name", awards: "name", competitions: "name", publications: "name" }[type];
    const aliases = schema.fields[primaryKey];
    return controlsForSection(schema).filter((control) => aliasesMatch(control, aliases)).length;
  }

  function addButtonForSection(type) {
    const schema = repeatSchemas[type];
    const candidates = elementsForSection(schema, "button,[role='button'],a");
    return candidates.find((button) => /^(添加|新增|增加|add)/i.test(normalize(button.textContent || button.getAttribute("aria-label"))));
  }

  async function waitForRows(type, previousCount) {
    for (let attempt = 0; attempt < 15; attempt += 1) {
      await new Promise((resolve) => setTimeout(resolve, 120));
      const count = primaryRowCount(type);
      if (count > previousCount) return count;
    }
    return primaryRowCount(type);
  }

  async function ensureRows(type, rawItems) {
    const items = meaningfulItems(type, rawItems);
    const target = items.length;
    let current = primaryRowCount(type);
    let added = 0;
    if (!target || current >= target) return { items, target, current, added, blocked: false };
    while (current < target) {
      const button = addButtonForSection(type);
      if (!button || button.disabled || button.getAttribute("aria-disabled") === "true") return { items, target, current, added, blocked: true };
      button.scrollIntoView({ block: "center", behavior: "auto" });
      button.click();
      const nextCount = await waitForRows(type, current);
      if (nextCount <= current) return { items, target, current, added, blocked: true };
      added += nextCount - current;
      current = nextCount;
    }
    return { items, target, current, added, blocked: false };
  }

  async function fillRepeated(type, items) {
    const schema = repeatSchemas[type];
    const controls = controlsForSection(schema);
    if (!controls.length || !items?.length) return { filled: 0, missingRows: items?.length || 0 };
    let filled = 0;
    let availableRows = Infinity;
    for (const [key, aliases] of Object.entries(schema.fields)) {
      const matches = controls.filter((control) => aliasesMatch(control, aliases));
      if (matches.length) availableRows = Math.min(availableRows, matches.length);
      for (let index = 0; index < Math.min(matches.length, items.length); index += 1) {
        if (!items[index][key] || currentValue(matches[index])) continue;
        if (await fillControl(matches[index], String(items[index][key]))) filled += 1;
      }
    }
    const dateControls = controls.filter((control) => /^(年|月)$/.test(control.placeholder || ""));
    const dateSlots = type === "awards" ? 2 : ["education", "experience", "projects", "competitions"].includes(type) ? 4 : 0;
    if (dateSlots && dateControls.length >= dateSlots) {
      availableRows = Math.min(availableRows, Math.floor(dateControls.length / dateSlots));
      for (let index = 0; index < Math.min(items.length, Math.floor(dateControls.length / dateSlots)); index += 1) {
        const parts = type === "awards" ? dateParts(items[index].date) : [...dateParts(items[index].startDate), ...dateParts(items[index].endDate)];
        for (let part = 0; part < parts.length; part += 1) {
          const control = dateControls[index * dateSlots + part];
          if (control && !currentValue(control) && setNativeValue(control, parts[part])) filled += 1;
        }
      }
    }
    if (availableRows === Infinity) availableRows = 0;
    return { filled, missingRows: Math.max(0, items.length - availableRows) };
  }

  async function fill(profile) {
    const values = flatten(profile);
    const elements = [...document.querySelectorAll("input,textarea,select")];
    let filled = 0, skipped = 0;
    const matchedKeys = new Set();
    const fieldUseCounts = {};
    for (const el of elements) {
      if (!isVisible(el) || el.type === "file") continue;
      const key = matchKey(labelText(el));
      if (!key || !values[key]) continue;
      matchedKeys.add(key);
      if (currentValue(el)) { skipped += 1; continue; }
      if (await fillControl(el, String(values[key]))) { filled += 1; fieldUseCounts[key] = (fieldUseCounts[key] || 0) + 1; }
    }
    const repeated = {};
    for (const type of ["education", "experience", "projects", "awards", "competitions", "publications"]) {
      const rowResult = await ensureRows(type, profile[type] || []);
      repeated[type] = { ...(await fillRepeated(type, rowResult.items)), addedRows: rowResult.added, addBlocked: rowResult.blocked };
      filled += repeated[type].filled;
    }
    const unmatched = Object.entries(values).filter(([key, value]) => value && fieldAliases[key] && !matchedKeys.has(key)).map(([key]) => fieldAliases[key][0]);
    return { filled, skipped, unmatched, repeated, fieldUseCounts };
  }

  function scan() {
    const missing = [];
    const controls = [...document.querySelectorAll("input,textarea,select")].filter(isVisible);
    controls.forEach((el) => {
      if (!["text", "email", "tel", "date", "number", "search", ""].includes(el.type) && !["TEXTAREA", "SELECT"].includes(el.tagName)) return;
      if (currentValue(el)) return;
      const text = labelText(el);
      const required = el.required || el.getAttribute("aria-required") === "true" || /必填|\*/.test(text);
      if (!required || blockedWords.some((word) => normalize(text).includes(normalize(word)))) return;
      const readable = text.replace(/\s+/g, " ").trim().slice(0, 40) || el.placeholder || "未命名字段";
      if (!missing.includes(readable)) missing.push(readable);
    });
    return { missing };
  }

  function base64ToBytes(base64) {
    const binary = atob(base64); const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function attachResume(profile) {
    const resume = profile.resume;
    if (!resume?.data) return { attached: false };
    const inputs = [...document.querySelectorAll("input[type='file']")];
    const target = inputs.find((input) => /简历|resume|cv/i.test(labelText(input)) || /pdf|doc|docx/i.test(input.accept || ""));
    if (!target) return { attached: false };
    try {
      const file = new File([base64ToBytes(resume.data)], resume.name, { type: resume.type, lastModified: Date.now() });
      const transfer = new DataTransfer(); transfer.items.add(file); target.files = transfer.files;
      target.dispatchEvent(new Event("input", { bubbles: true })); target.dispatchEvent(new Event("change", { bubbles: true }));
      return { attached: target.files?.length === 1 };
    } catch { return { attached: false }; }
  }

  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (message.action === "fill") { fill(message.profile).then(respond); return true; }
    else if (message.action === "scan") respond(scan());
    else if (message.action === "attachResume") respond(attachResume(message.profile));
  });
})();
